<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';
require_method('POST');

$data = request_data();
require_fields($data, ['full_name', 'email', 'phone', 'date_of_birth', 'password', 'confirm_password']);

if (mb_strlen(trim((string)$data['full_name'])) < 2) {
    respond_error('Full name must contain at least 2 characters.', 422);
}
$email = normalize_email((string)$data['email']);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond_error('Please enter a valid email address.', 422);
}
if ((string)$data['password'] !== (string)$data['confirm_password']) {
    respond_error('Passwords do not match.', 422);
}
if (mb_strlen((string)$data['password']) < 6) {
    respond_error('Password must contain at least 6 characters.', 422);
}

$exists = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
$exists->execute([':email' => $email]);
if ($exists->fetch()) {
    respond_error('An account with this email already exists.', 409);
}

$insert = $pdo->prepare(
    'INSERT INTO users
     (public_id, full_name, email, phone, date_of_birth, password_hash, role, locale, created_at, updated_at)
     VALUES
     (:public_id, :full_name, :email, :phone, :date_of_birth, :password_hash, "user", :locale, UTC_TIMESTAMP(), UTC_TIMESTAMP())'
);

$insert->execute([
    ':public_id' => generate_public_id('TG'),
    ':full_name' => trim((string)$data['full_name']),
    ':email' => $email,
    ':phone' => trim((string)$data['phone']),
    ':date_of_birth' => trim((string)$data['date_of_birth']),
    ':password_hash' => password_hash((string)$data['password'], PASSWORD_DEFAULT),
    ':locale' => in_array(($data['locale'] ?? 'en'), ['he', 'en'], true) ? $data['locale'] : 'en',
]);

$userId = (int)$pdo->lastInsertId();
$token = issue_auth_token($pdo, $userId);

$userStmt = $pdo->prepare(
    'SELECT id, public_id, full_name, email, phone, date_of_birth, avatar_url, role, locale,
            notifications_enabled, dark_mode, location_services_enabled, points_balance
     FROM users WHERE id = :id LIMIT 1'
);
$userStmt->execute([':id' => $userId]);

respond_success([
    'token' => $token,
    'user' => $userStmt->fetch(),
], 201);
