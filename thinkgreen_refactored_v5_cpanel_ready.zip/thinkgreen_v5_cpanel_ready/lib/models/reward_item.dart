class RewardItem {
  final String id;
  final String title;
  final int cost;
  final String emoji;
  final String partnerName;
  final String description;

  const RewardItem({
    required this.id,
    required this.title,
    required this.cost,
    required this.emoji,
    required this.partnerName,
    required this.description,
  });
}

class RewardRedemption {
  final String id;
  final RewardItem reward;
  final DateTime redeemedAt;
  final String redemptionCode;

  const RewardRedemption({
    required this.id,
    required this.reward,
    required this.redeemedAt,
    required this.redemptionCode,
  });
}

class PartnerBusiness {
  final String name;
  final String rewards;
  final String location;

  const PartnerBusiness({
    required this.name,
    required this.rewards,
    required this.location,
  });
}
