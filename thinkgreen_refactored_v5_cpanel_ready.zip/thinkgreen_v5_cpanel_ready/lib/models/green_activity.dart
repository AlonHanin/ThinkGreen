import 'dart:typed_data';

import 'package:uuid/uuid.dart';

enum ActivitySource { manual, strava, moovit }
enum ActivityStatus { pending, approved, rejected }

class GreenActivity {
  final String id;
  final String title;
  final ActivitySource source;
  final DateTime dateTime;
  final int points;
  final String? imageUrl;
  final Uint8List? imageBytes;
  final String? userName;
  ActivityStatus status;

  GreenActivity({
    String? id,
    required this.title,
    required this.source,
    required this.dateTime,
    required this.points,
    this.imageUrl,
    this.imageBytes,
    this.userName,
    this.status = ActivityStatus.pending,
  }) : id = id ?? const Uuid().v4();

  GreenActivity copyWith({
    String? id,
    String? title,
    ActivitySource? source,
    DateTime? dateTime,
    int? points,
    String? imageUrl,
    Uint8List? imageBytes,
    String? userName,
    ActivityStatus? status,
  }) {
    return GreenActivity(
      id: id ?? this.id,
      title: title ?? this.title,
      source: source ?? this.source,
      dateTime: dateTime ?? this.dateTime,
      points: points ?? this.points,
      imageUrl: imageUrl ?? this.imageUrl,
      imageBytes: imageBytes ?? this.imageBytes,
      userName: userName ?? this.userName,
      status: status ?? this.status,
    );
  }
}
