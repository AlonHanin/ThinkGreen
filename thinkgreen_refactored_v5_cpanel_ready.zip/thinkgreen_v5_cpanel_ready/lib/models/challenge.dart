class Challenge {
  final String id;
  final String title;
  final String description;
  final int points;
  final String icon;
  final int targetCount;
  int currentCount;
  final DateTime endDate;
  final List<String> trackingKeywords;
  final String linkedActivityTitle;

  Challenge({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.targetCount,
    this.currentCount = 0,
    required this.endDate,
    this.icon = '🏆',
    this.trackingKeywords = const [],
    required this.linkedActivityTitle,
  });

  double get progress => (currentCount / targetCount).clamp(0.0, 1.0);

  bool get isCompleted => currentCount >= targetCount;

  int get daysLeft {
    final days = endDate.difference(DateTime.now()).inDays;
    return days < 0 ? 0 : days;
  }
}
