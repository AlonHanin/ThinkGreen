import 'package:device_preview/device_preview.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'l10n_app_localizations.dart';
import 'main_navigation_screen.dart';
import 'providers/activity_provider.dart';
import 'providers/challenge_provider.dart';
import 'providers/reward_provider.dart';
import 'providers/session_provider.dart';
import 'screens/activities/activity_history_screen.dart';
import 'screens/activities/manual_report_screen.dart';
import 'screens/activities/sync_apps_screen.dart';
import 'screens/auth/forgot_password_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/reset_password_screen.dart';
import 'screens/auth/security_pin_screen.dart';
import 'screens/auth/signin_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/auth/splash_screen.dart';
import 'screens/rewards/redeem_screen.dart';

void main() {
  runApp(
    DevicePreview(
      enabled: !kReleaseMode,
      builder: (context) => MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => SessionProvider()),
          ChangeNotifierProvider(create: (_) => ActivityProvider()),
          ChangeNotifierProxyProvider<ActivityProvider, ChallengeProvider>(
            create: (_) => ChallengeProvider(),
            update: (_, activityProvider, challengeProvider) =>
                challengeProvider!..syncFromActivities(activityProvider.activities),
          ),
          ChangeNotifierProxyProvider2<ActivityProvider, ChallengeProvider, RewardProvider>(
            create: (_) => RewardProvider(),
            update: (_, activityProvider, challengeProvider, rewardProvider) =>
                rewardProvider!..syncEarnedPoints(
                  totalApprovedPoints: activityProvider.totalPoints,
                  challengeBonusPoints: challengeProvider.totalBonusPoints,
                ),
          ),
        ],
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SessionProvider>(
      builder: (context, sessionProvider, _) {
        return MaterialApp(
          locale: sessionProvider.locale,
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: AppLocalizations.localizationsDelegates,
          builder: (context, child) {
            final preview = DevicePreview.appBuilder(context, child);
            return Directionality(
              textDirection: sessionProvider.locale.languageCode == 'he'
                  ? TextDirection.rtl
                  : TextDirection.ltr,
              child: preview,
            );
          },
          debugShowCheckedModeBanner: false,
          title: 'Think Green',
          theme: ThemeData(
            primarySwatch: Colors.green,
            scaffoldBackgroundColor: const Color(0xFFE0E0E0),
            fontFamily: 'Outfit',
            brightness: Brightness.light,
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            primarySwatch: Colors.green,
          ),
          themeMode: sessionProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
          initialRoute: '/',
          routes: {
            '/': (context) => const SplashScreen(),
            '/login': (context) => const LoginScreen(),
            '/signin': (context) => const SignInScreen(),
            '/signup': (context) => const SignUpScreen(),
            '/forgot_password': (context) => const ForgotPasswordScreen(),
            '/security_pin': (context) => const SecurityPinScreen(),
            '/reset_password': (context) => const ResetPasswordScreen(),
            '/home': (context) => MainNavigationScreen(),
            '/redeem': (context) => const RedeemScreen(),
            '/history': (context) => const ActivityHistoryScreen(),
            '/manual_report': (context) => const ManualReportScreen(),
            '/sync_apps': (context) => const SyncAppsScreen(),
          },
        );
      },
    );
  }
}
