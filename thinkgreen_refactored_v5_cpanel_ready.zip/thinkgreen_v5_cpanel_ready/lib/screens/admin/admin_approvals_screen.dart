import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/green_activity.dart';
import '../../providers/activity_provider.dart';
import '../../l10n_app_localizations.dart';
import '../../utils/app_feedback.dart';

class AdminApprovalsScreen extends StatelessWidget {
  const AdminApprovalsScreen({super.key});

  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  @override
  Widget build(BuildContext context) {
    final pendingActivities = context.watch<ActivityProvider>().pendingActivities;

    return Scaffold(
                  backgroundColor: lightGreenBg,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text(
                      context.tr('Review Requests'),
                      style: GoogleFonts.outfit(
                        color: darkGreen,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    centerTitle: true,
                  ),
                  body: pendingActivities.isEmpty
                      ? _buildEmptyState(context)
                      : ListView.builder(
                          padding: const EdgeInsets.all(15),
                          itemCount: pendingActivities.length,
                          itemBuilder: (context, index) => _buildReviewCard(
                            context,
                            pendingActivities[index],
                          ),
                        ),
                );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.done_all_rounded,
            size: 80,
            color: darkGreen.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 15),
          Text(
            context.tr('All caught up!'),
            style: GoogleFonts.outfit(
              fontSize: 20,
              color: darkGreen,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            context.tr('No pending requests to review.'),
            style: TextStyle(color: darkGreen.withValues(alpha: 0.5)),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewCard(BuildContext context, GreenActivity activity) {
    final hasImageBytes = activity.imageBytes != null && activity.imageBytes!.isNotEmpty;
    final hasLocalImage = !kIsWeb &&
        activity.imageUrl != null &&
        activity.imageUrl!.isNotEmpty &&
        File(activity.imageUrl!).existsSync();
    final hasWebImageUrl = kIsWeb &&
        activity.imageUrl != null &&
        activity.imageUrl!.isNotEmpty;
    final imageExists = hasImageBytes || hasLocalImage || hasWebImageUrl;

    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: lightGreenBg,
              child: Icon(Icons.person, color: darkGreen),
            ),
            title: Text(
              activity.userName ?? 'Unknown User',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(activity.title),
            trailing: Text(
              '+${activity.points}',
              style: const TextStyle(
                color: Colors.orange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Submitted: ${DateFormat('dd/MM/yyyy • HH:mm').format(activity.dateTime)}',
              style: TextStyle(
                color: darkGreen.withValues(alpha: 0.6),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          if (imageExists) ...[
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: hasImageBytes
                    ? Image.memory(
                        activity.imageBytes!,
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      )
                    : hasLocalImage
                        ? Image.file(
                            File(activity.imageUrl!),
                            height: 180,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          )
                        : Image.network(
                            activity.imageUrl!,
                            height: 180,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
              ),
            ),
          ],
          Padding(
            padding: const EdgeInsets.all(15),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      context.read<ActivityProvider>().rejectActivity(activity.id);
                      showAppSnackBar(context, context.tr('Activity rejected.'));
                    },
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.red),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      context.tr('Reject'),
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      context.read<ActivityProvider>().approveActivity(activity.id);
                      showAppSnackBar(context, context.tr('Activity approved and points granted.'));
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: darkGreen,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      context.tr('Approve'),
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
