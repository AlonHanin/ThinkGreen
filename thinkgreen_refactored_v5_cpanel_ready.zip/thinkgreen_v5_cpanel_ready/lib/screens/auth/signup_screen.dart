import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../l10n_app_localizations.dart';
import '../../main_navigation_screen.dart';
import '../../providers/session_provider.dart';
import '../../utils/app_feedback.dart';
import '../../widgets/google_button.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmController = TextEditingController();

  bool _isPasswordVisible = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _dobController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  Future<void> _pickDateOfBirth() async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime(2000, 1, 1),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );

    if (pickedDate == null) return;

    final day = pickedDate.day.toString().padLeft(2, '0');
    final month = pickedDate.month.toString().padLeft(2, '0');
    _dobController.text = '$day/$month/${pickedDate.year}';
  }

  void _handleSignUp() {
    final sessionProvider = context.read<SessionProvider>();
    final error = sessionProvider.signUp(
      fullName: _nameController.text,
      email: _emailController.text,
      phone: _phoneController.text,
      dateOfBirth: _dobController.text,
      password: _passwordController.text,
      confirmPassword: _confirmController.text,
    );

    if (error != null) {
      showAppSnackBar(context, context.tr(error), backgroundColor: Colors.red.shade700);
      return;
    }

    showAppSnackBar(context, context.tr('Account created successfully.'));
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => MainNavigationScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      body: SafeArea(
        child: Container(
                            decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Color(0xFF1B5E20),
                          ),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Text(
                          context.tr('Create Account'),
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1B5E20),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(25),
                      child: Column(
                        children: [
                          _buildInputLabel(context.tr('Full Name')),
                          const SizedBox(height: 8),
                          _buildTextField(
                            _nameController,
                            'John Green',
                            Icons.person_outline,
                          ),
                          const SizedBox(height: 15),
                          _buildInputLabel(context.tr('Email')),
                          const SizedBox(height: 8),
                          _buildTextField(
                            _emailController,
                            'example@example.com',
                            Icons.email_outlined,
                          ),
                          const SizedBox(height: 15),
                          _buildInputLabel(context.tr('Mobile Number')),
                          const SizedBox(height: 8),
                          _buildTextField(
                            _phoneController,
                            '+972 50 123 4567',
                            Icons.phone_android_outlined,
                          ),
                          const SizedBox(height: 15),
                          _buildInputLabel(context.tr('Date Of Birth')),
                          const SizedBox(height: 8),
                          GestureDetector(
                            onTap: _pickDateOfBirth,
                            child: AbsorbPointer(
                              child: _buildTextField(
                                _dobController,
                                'DD/MM/YYYY',
                                Icons.calendar_today_outlined,
                              ),
                            ),
                          ),
                          const SizedBox(height: 15),
                          _buildInputLabel(context.tr('Password')),
                          const SizedBox(height: 8),
                          _buildTextField(
                            _passwordController,
                            '••••••••',
                            Icons.lock_outline,
                            isPassword: true,
                          ),
                          const SizedBox(height: 15),
                          _buildInputLabel(context.tr('Confirm Password')),
                          const SizedBox(height: 8),
                          _buildTextField(
                            _confirmController,
                            '••••••••',
                            Icons.lock_reset_outlined,
                            isPassword: true,
                          ),
                          const SizedBox(height: 25),
                          _buildSignUpButton(context),
                          const SizedBox(height: 10),
                          TextButton(
                            onPressed: () => Navigator.pushReplacementNamed(
                              context,
                              '/signin',
                            ),
                            child: Text(
                              context.tr('Already have an account? Log In'),
                              style: TextStyle(
                                color: Color(0xFF00695C),
                                fontSize: 12,
                              ),
                            ),
                          ),
                          Text(
                            context.tr('Or sign up with'),
                            style: TextStyle(color: Colors.grey[600], fontSize: 12),
                          ),
                          const SizedBox(height: 12),
                          GoogleSignInButton(
                            onPressed: () => showComingSoonSnackBar(
                              context,
                              feature: 'Google sign up',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
      ),
    );
  }

  Widget _buildInputLabel(String label) {
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Text(
        label,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Color(0xFF1B5E20),
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String hint,
    IconData icon, {
    bool isPassword = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: isPassword && !_isPasswordVisible,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        hintText: hint,
        prefixIcon: Icon(icon, color: const Color(0xFF00695C), size: 20),
        suffixIcon: isPassword
            ? IconButton(
                icon: Icon(
                  _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                  size: 20,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              )
            : null,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12),
      ),
    );
  }

  Widget _buildSignUpButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: _handleSignUp,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF00695C),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
        child: Text(
          context.tr('Sign Up'),
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
