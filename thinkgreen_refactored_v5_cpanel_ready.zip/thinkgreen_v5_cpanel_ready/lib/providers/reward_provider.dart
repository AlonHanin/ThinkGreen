import 'dart:math';

import 'package:flutter/material.dart';

import '../models/reward_item.dart';

class RewardProvider with ChangeNotifier {
  final List<RewardItem> _catalog = const [
    RewardItem(
      id: 'reward-1',
      title: 'Free Coffee (Reusable Cup)',
      cost: 250,
      emoji: '☕',
      partnerName: 'Eco Coffee Hub',
      description: 'One free regular coffee when using a reusable cup.',
    ),
    RewardItem(
      id: 'reward-2',
      title: '10% Store Discount',
      cost: 300,
      emoji: '🛍️',
      partnerName: 'Green Fashion',
      description: 'Single-use 10% discount on one purchase.',
    ),
    RewardItem(
      id: 'reward-3',
      title: 'Bus Ticket Credit',
      cost: 200,
      emoji: '🚌',
      partnerName: 'City Transit Desk',
      description: 'Transit credit voucher for one bus ride.',
    ),
    RewardItem(
      id: 'reward-4',
      title: 'Tree Planting Donation',
      cost: 300,
      emoji: '🌳',
      partnerName: 'Green Earth NGO',
      description: 'Convert your points into a sponsored tree planting.',
    ),
    RewardItem(
      id: 'reward-5',
      title: 'Free Drink Upgrade',
      cost: 200,
      emoji: '🥤',
      partnerName: 'Bio Bakery',
      description: 'Upgrade one drink size for free.',
    ),
  ];

  final List<PartnerBusiness> _partnerBusinesses = const [
    PartnerBusiness(
      name: 'Eco Coffee Hub',
      rewards: 'Coffee rewards, reusable cup benefits',
      location: 'Main St. 12',
    ),
    PartnerBusiness(
      name: 'Green Fashion',
      rewards: 'Discounts, tote bags, eco accessories',
      location: 'Shopping Mall, Floor 1',
    ),
    PartnerBusiness(
      name: 'Nature Market',
      rewards: 'Fresh produce discounts',
      location: 'North Ave. 45',
    ),
    PartnerBusiness(
      name: 'Bio Bakery',
      rewards: 'Free drink upgrades and pastry deals',
      location: 'Central Square',
    ),
  ];

  final List<RewardRedemption> _activeRedemptions = [];

  int _earnedPoints = 0;

  List<RewardItem> get catalog => List.unmodifiable(_catalog);
  List<PartnerBusiness> get partnerBusinesses => List.unmodifiable(_partnerBusinesses);
  List<RewardRedemption> get activeRedemptions =>
      List.unmodifiable(_activeRedemptions.reversed.toList());
  int get earnedPoints => _earnedPoints;

  int get spentPoints => _activeRedemptions.fold(0, (sum, item) => sum + item.reward.cost);

  int get availablePoints => max(_earnedPoints - spentPoints, 0);

  int get nextRewardThreshold {
    final thresholds = _catalog.map((reward) => reward.cost).toSet().toList()..sort();
    for (final threshold in thresholds) {
      if (threshold > availablePoints) return threshold;
    }
    return thresholds.isEmpty ? 0 : thresholds.last;
  }

  double get progressToNextReward {
    final next = nextRewardThreshold;
    if (next == 0) return 1;
    return (availablePoints / next).clamp(0.0, 1.0);
  }

  void syncEarnedPoints({
    required int totalApprovedPoints,
    required int challengeBonusPoints,
  }) {
    final total = totalApprovedPoints + challengeBonusPoints;
    if (_earnedPoints == total) return;
    _earnedPoints = total;
    notifyListeners();
  }

  String? redeemReward(RewardItem reward) {
    if (availablePoints < reward.cost) {
      return 'Not enough points to redeem this reward yet.';
    }

    final redemption = RewardRedemption(
      id: 'redemption-${DateTime.now().millisecondsSinceEpoch}',
      reward: reward,
      redeemedAt: DateTime.now(),
      redemptionCode: 'TG-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
    );

    _activeRedemptions.add(redemption);
    notifyListeners();
    return null;
  }

  String qrPayloadFor(RewardRedemption redemption) {
    return 'thinkgreen://reward/${redemption.redemptionCode}/${redemption.reward.id}';
  }
}
