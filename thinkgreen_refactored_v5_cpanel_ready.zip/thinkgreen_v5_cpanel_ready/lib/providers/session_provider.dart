import 'package:flutter/material.dart';

import '../models/app_user.dart';

class SessionProvider with ChangeNotifier {
  static const String demoSecurityPin = '2468';
  static const String adminAccessCode = 'TG-ADMIN-2026';

  AppUser _currentUser = AppUser(
    id: 'TG-25030024',
    fullName: 'Alon Green',
    email: 'alon@thinkgreen.app',
    phone: '+972 50 123 4567',
    password: 'GreenPass123',
    dateOfBirth: DateTime(1995, 3, 12),
  );

  bool _isAuthenticated = false;
  bool _notificationsEnabled = true;
  bool _isDarkMode = false;
  bool _locationServicesEnabled = true;
  Locale _locale = const Locale('en');

  AppUser get currentUser => _currentUser;
  bool get isAuthenticated => _isAuthenticated;
  bool get notificationsEnabled => _notificationsEnabled;
  bool get isDarkMode => _isDarkMode;
  bool get locationServicesEnabled => _locationServicesEnabled;
  Locale get locale => _locale;
  String get language => _locale.languageCode == 'he' ? 'Hebrew' : 'English';

  bool emailExists(String email) {
    return _normalize(email) == _normalize(_currentUser.email);
  }

  bool verifySecurityPin(String pin) => pin.trim() == demoSecurityPin;

  String? signIn({required String email, required String password}) {
    if (!_isValidEmail(email)) {
      return 'Please enter a valid email address.';
    }
    if (_normalize(email) != _normalize(_currentUser.email)) {
      return 'No account was found for this email.';
    }
    if (password != _currentUser.password) {
      return 'Incorrect password. Please try again.';
    }

    _isAuthenticated = true;
    notifyListeners();
    return null;
  }

  String? signUp({
    required String fullName,
    required String email,
    required String phone,
    required String dateOfBirth,
    required String password,
    required String confirmPassword,
  }) {
    if (fullName.trim().length < 2) {
      return 'Please enter your full name.';
    }
    if (!_isValidEmail(email)) {
      return 'Please enter a valid email address.';
    }
    if (phone.trim().length < 8) {
      return 'Please enter a valid phone number.';
    }
    if (dateOfBirth.trim().isEmpty) {
      return 'Please select your date of birth.';
    }
    if (password.length < 6) {
      return 'Password must contain at least 6 characters.';
    }
    if (password != confirmPassword) {
      return 'Passwords do not match.';
    }

    _currentUser = AppUser(
      id: 'TG-${DateTime.now().millisecondsSinceEpoch}',
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      password: password,
      dateOfBirth: _parseDate(dateOfBirth),
    );
    _isAuthenticated = true;
    notifyListeners();
    return null;
  }

  String? resetPassword({
    required String email,
    required String pin,
    required String newPassword,
    required String confirmPassword,
  }) {
    if (!emailExists(email)) {
      return 'This email does not match any existing account.';
    }
    if (!verifySecurityPin(pin)) {
      return 'The security PIN is invalid.';
    }
    if (newPassword.length < 6) {
      return 'Password must contain at least 6 characters.';
    }
    if (newPassword != confirmPassword) {
      return 'Passwords do not match.';
    }

    _currentUser = _currentUser.copyWith(password: newPassword);
    _isAuthenticated = false;
    notifyListeners();
    return null;
  }

  void updateProfile({
    required String fullName,
    required String email,
    required String phone,
  }) {
    _currentUser = _currentUser.copyWith(
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
    );
    notifyListeners();
  }

  void setNotificationsEnabled(bool value) {
    _notificationsEnabled = value;
    notifyListeners();
  }

  void setDarkMode(bool value) {
    _isDarkMode = value;
    notifyListeners();
  }

  void setLocationServicesEnabled(bool value) {
    _locationServicesEnabled = value;
    notifyListeners();
  }

  void setLocale(Locale value) {
    if (_locale == value) return;
    _locale = value;
    notifyListeners();
  }

  void setLanguage(String value) {
    setLocale(value.toLowerCase().contains('he') ? const Locale('he') : const Locale('en'));
  }

  void logout() {
    _isAuthenticated = false;
    notifyListeners();
  }

  String _normalize(String value) => value.trim().toLowerCase();

  bool _isValidEmail(String email) {
    final trimmed = email.trim();
    return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(trimmed);
  }

  DateTime? _parseDate(String input) {
    final parts = input.split('/').map((part) => part.trim()).toList();
    if (parts.length != 3) return null;

    final day = int.tryParse(parts[0]);
    final month = int.tryParse(parts[1]);
    final year = int.tryParse(parts[2]);
    if (day == null || month == null || year == null) return null;

    return DateTime(year, month, day);
  }
}
