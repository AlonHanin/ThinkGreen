import 'package:flutter/material.dart';

import '../models/green_activity.dart';

class ActivityProvider with ChangeNotifier {
  final List<GreenActivity> _activities = [];

  List<GreenActivity> get activities => List.unmodifiable(_activities);

  List<GreenActivity> get approvedActivities => _activities
      .where((activity) => activity.status == ActivityStatus.approved)
      .toList(growable: false);

  List<GreenActivity> get pendingActivities => _activities
      .where((activity) => activity.status == ActivityStatus.pending)
      .toList(growable: false);

  List<GreenActivity> get rejectedActivities => _activities
      .where((activity) => activity.status == ActivityStatus.rejected)
      .toList(growable: false);

  int get totalPoints {
    return approvedActivities.fold(0, (sum, activity) => sum + activity.points);
  }

  List<GreenActivity> recentActivities({int limit = 5}) {
    final copy = [..._activities]..sort((a, b) => b.dateTime.compareTo(a.dateTime));
    return copy.take(limit).toList(growable: false);
  }

  void addActivity(GreenActivity activity) {
    _activities.add(activity);
    _activities.sort((a, b) => b.dateTime.compareTo(a.dateTime));
    notifyListeners();
  }

  void approveActivity(String id) {
    final index = _activities.indexWhere((activity) => activity.id == id);
    if (index == -1) return;
    if (_activities[index].status == ActivityStatus.approved) return;

    _activities[index].status = ActivityStatus.approved;
    notifyListeners();
  }

  void rejectActivity(String id) {
    final index = _activities.indexWhere((activity) => activity.id == id);
    if (index == -1) return;
    if (_activities[index].status == ActivityStatus.rejected) return;

    _activities[index].status = ActivityStatus.rejected;
    notifyListeners();
  }
}
