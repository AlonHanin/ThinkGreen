import 'package:flutter/material.dart';

import '../models/challenge.dart';
import '../models/green_activity.dart';

class ChallengeProvider with ChangeNotifier {
  final List<Challenge> _challenges = [
    Challenge(
      id: '1',
      title: 'No Plastic Week',
      description: 'Use a reusable bottle or skip plastic bags for 7 actions.',
      points: 500,
      targetCount: 7,
      endDate: DateTime.now().add(const Duration(days: 7)),
      icon: '♻️',
      trackingKeywords: const ['reusable', 'bottle', 'plastic'],
      linkedActivityTitle: 'Used A Reusable Bottle',
    ),
    Challenge(
      id: '2',
      title: 'Public Transport Streak',
      description: 'Choose buses or public transport 5 times this week.',
      points: 350,
      targetCount: 5,
      endDate: DateTime.now().add(const Duration(days: 7)),
      icon: '🚌',
      trackingKeywords: const ['public transport', 'bus', 'moovit', 'transport'],
      linkedActivityTitle: 'Used Public Transport',
    ),
    Challenge(
      id: '3',
      title: 'Recycling Sprint',
      description: 'Submit and complete 3 recycling actions.',
      points: 250,
      targetCount: 3,
      endDate: DateTime.now().add(const Duration(days: 7)),
      icon: '🌱',
      trackingKeywords: const ['recycled', 'recycling', 'bottle'],
      linkedActivityTitle: 'Recycled Plastic Bottles',
    ),
  ];

  List<Challenge> get challenges => List.unmodifiable(_challenges);

  List<Challenge> get completedChallenges =>
      _challenges.where((challenge) => challenge.isCompleted).toList(growable: false);

  int get totalBonusPoints =>
      completedChallenges.fold(0, (sum, challenge) => sum + challenge.points);

  void addChallenge(Challenge challenge) {
    _challenges.insert(0, challenge);
    notifyListeners();
  }

  void syncFromActivities(List<GreenActivity> activities) {
    final approvedActivities = activities
        .where((activity) => activity.status == ActivityStatus.approved)
        .toList(growable: false);

    var hasChanges = false;
    for (final challenge in _challenges) {
      final newCount = _countMatches(approvedActivities, challenge);
      if (challenge.currentCount != newCount) {
        challenge.currentCount = newCount;
        hasChanges = true;
      }
    }

    if (hasChanges) {
      notifyListeners();
    }
  }

  int _countMatches(List<GreenActivity> activities, Challenge challenge) {
    if (challenge.trackingKeywords.isEmpty) {
      return activities.length;
    }

    return activities.where((activity) {
      final title = activity.title.toLowerCase();
      return challenge.trackingKeywords.any(
        (keyword) => title.contains(keyword.toLowerCase()),
      );
    }).length;
  }
}
