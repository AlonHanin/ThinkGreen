// זהו הקובץ הראשי של האפליקציה, שמגדיר את נקודת הכניסה שלה ומכיל את הגדרת ה-Theme, הניווט הראשוני והפרוביידרים. הוא גם כולל את Device Preview כדי לאפשר בדיקות על מכשירים שונים במהלך הפיתוח.


import 'package:flutter/foundation.dart'; // נדרש עבור kReleaseMode
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:device_preview/device_preview.dart'; // הייבוא החדש

// ייבוא המסכים שלך
import 'screens/auth/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signin_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/auth/forgot_password_screen.dart';
import 'screens/auth/security_pin_screen.dart';
import 'screens/auth/reset_password_screen.dart';
import 'main_navigation_screen.dart';
import 'screens/activities/activity_history_screen.dart';
import 'screens/activities/manual_report_screen.dart';
import 'screens/activities/sync_apps_screen.dart';
import 'screens/rewards/redeem_screen.dart';

// ייבוא הפרובאיידרים
import 'providers/activity_provider.dart';
import 'providers/challenge_provider.dart';

void main() {
  runApp(
    DevicePreview(
      enabled: !kReleaseMode, // פועל רק במצב פיתוח, לא באפליקציה סופית
      builder: (context) => MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => ActivityProvider()),
          ChangeNotifierProvider(create: (_) => ChallengeProvider()),
        ],
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // הגדרות Device Preview
      // ignore: deprecated_member_use
      useInheritedMediaQuery: true, 
      locale: DevicePreview.locale(context),
      builder: DevicePreview.appBuilder,
      
      debugShowCheckedModeBanner: false,
      title: 'Think Green',
      
      // הגדרת ערכת נושא (Theme)
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFE0E0E0),
        fontFamily: 'Outfit',
        brightness: Brightness.light,
      ),
      // הגדרת ערכת נושא כהה (Dark Theme)
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.green,
      ),

      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/signin': (context) => const SignInScreen(),
        '/signup': (context) => const SignUpScreen(),
        '/forgot_password': (context) => const ForgotPasswordScreen(),
        '/security_pin': (context) => const SecurityPinScreen(),
        '/reset_password': (context) => const ResetPasswordScreen(),
        '/home': (context) => MainNavigationScreen(), 
        '/redeem': (context) => const RedeemScreen(),
        '/history': (context) => const ActivityHistoryScreen(),
        '/manual_report': (context) => const ManualReportScreen(),
        '/sync_apps': (context) => const SyncAppsScreen(),
      },
    );
  }
}