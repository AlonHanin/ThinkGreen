class Challenge {
  final String id;
  final String title;
  final String description;
  final int points;
  final String icon;
  final int targetCount;      // כמה פעמים צריך לבצע
  int currentCount;           // כמה בוצע בפועל
  final DateTime endDate;     // מתי האתגר נגמר

  Challenge({
    required this.id,
    required this.title,
    required this.description,
    required this.points,
    required this.targetCount,
    this.currentCount = 0,
    required this.endDate,
    this.icon = '🏆',
  });

  double get progress => (currentCount / targetCount).clamp(0.0, 1.0);
  int get daysLeft => endDate.difference(DateTime.now()).inDays;
}