import 'package:uuid/uuid.dart';

// מקור הפעילות
enum ActivitySource { manual, strava, moovit }

// מצב האישור של הפעילות (חדש!)
enum ActivityStatus { pending, approved, rejected }

class GreenActivity {
  final String id;
  final String title;
  final ActivitySource source;
  final DateTime dateTime;
  final int points;
  
  // שדות חדשים למנגנון האישורים:
  final String? imageUrl;    // נתיב לתמונה שהמשתמש צילם
  ActivityStatus status;     // מצב האישור (ברירת מחדל: ממתין)
  final String? userName;    // שם המשתמש (כדי שהאדמין ידע למי הוא מאשר)

  GreenActivity({
    String? id,
    required this.title,
    required this.source,
    required this.dateTime,
    required this.points,
    this.imageUrl,
    this.status = ActivityStatus.pending, // כל פעילות חדשה מתחילה ב-Pending
    this.userName, required String imagePath,
  }) : id = id ?? const Uuid().v4();
}