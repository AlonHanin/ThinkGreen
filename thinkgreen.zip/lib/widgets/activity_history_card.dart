//זהו כרטיס היסטוריית פעילות שמוצג ברשימת ההיסטוריה. הוא מציג את שם הפעילות, התאריך והשעה, מקור הפעילות (ידני או סריקת QR), ואת הנקודות שהמשתמש קיבל עבור הפעילות הזו. העיצוב שלו נקי ומודרני, עם צבעים ירוקים ואפורים כדי להדגיש את המידע החשוב.


import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/green_activity.dart';

class ActivityHistoryCard extends StatelessWidget {
  final GreenActivity activity;

  const ActivityHistoryCard({super.key, required this.activity});

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        // יישור ה-Row הראשי לתחתית כדי שהנקודות יהיו למטה
        crossAxisAlignment: CrossAxisAlignment.end, 
        children: [
          // צד שמאל: אייקון ומידע על הפעילות
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: darkGreen.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    activity.source == ActivitySource.manual 
                        ? Icons.edit_note 
                        : Icons.qr_code_scanner,
                    color: darkGreen,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        activity.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: darkGreen,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        DateFormat('dd/MM/yyyy | HH:mm').format(activity.dateTime),
                        style: TextStyle(
                          fontSize: 12,
                          color: darkGreen.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // צד ימין למטה: הרובריקה האפורה של הנקודות
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFF2F2F2), // אפור בהיר
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '+${activity.points} pts',
              style: const TextStyle(
                color: darkGreen,
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}