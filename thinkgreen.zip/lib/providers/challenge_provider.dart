import 'package:flutter/material.dart';
import '../models/challenge.dart';

class ChallengeProvider with ChangeNotifier {
  final List<Challenge> _challenges = [
    // עדכון אתגר ברירת המחדל עם הנתונים החדשים
    Challenge(
      id: '1', 
      title: 'No Plastic Week', 
      description: 'Dont use plastic bags for 7 days', 
      points: 500,
      targetCount: 7,
      endDate: DateTime.now().add(const Duration(days: 7)),
      icon: '♻️'
    ),
  ];

  List<Challenge> get challenges => _challenges;

  void addChallenge(Challenge challenge) {
    _challenges.insert(0, challenge);
    notifyListeners();
  }
}