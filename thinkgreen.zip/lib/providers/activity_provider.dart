import 'package:flutter/material.dart';
import '../models/green_activity.dart';

class ActivityProvider with ChangeNotifier {
  final List<GreenActivity> _activities = [];

  List<GreenActivity> get activities => _activities;

  // מחשב נקודות רק עבור פעילויות שאושרו!
  int get totalPoints {
    return _activities
        .where((a) => a.status == ActivityStatus.approved)
        .fold(0, (sum, a) => sum + a.points);
  }

  // הוספת פעילות חדשה (במצב Pending כברירת מחדל)
  void addActivity(GreenActivity activity) {
    _activities.insert(0, activity);
    notifyListeners();
  }

  // פונקציה לאדמין: אישור פעילות
  void approveActivity(String id) {
    final index = _activities.indexWhere((a) => a.id == id);
    if (index != -1) {
      _activities[index].status = ActivityStatus.approved;
      notifyListeners();
    }
  }

  // פונקציה לאדמין: דחיית פעילות
  void rejectActivity(String id) {
    final index = _activities.indexWhere((a) => a.id == id);
    if (index != -1) {
      _activities[index].status = ActivityStatus.rejected;
      notifyListeners();
    }
  }
}