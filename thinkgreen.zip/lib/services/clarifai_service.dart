/*
 * תיאור: שירות המקשר בין האפליקציה ל-API של Clarifai לצורך זיהוי אובייקטים בתמונה.
 */

import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class ClarifaiService {
  // כאן תכניס את ה-API Key שלך מהאתר של Clarifai
  final String _apiKey = 'YOUR_CLARIFAI_API_KEY';
  final String _modelId = 'general-image-recognition'; // מודל כללי חזק

  Future<List<String>> analyzeImage(File imageFile) async {
    final String base64Image = base64Encode(await imageFile.readAsBytes());

    final url = Uri.parse('https://api.clarifai.com/v2/models/$_modelId/outputs');

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Key $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "inputs": [
            {
              "data": {
                "image": {"base64": base64Image}
              }
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List concepts = data['outputs'][0]['data']['concepts'];
        
        // מחזירים רק את שמות התגיות (Concepts)
        return concepts.map((c) => c['name'].toString().toLowerCase()).toList();
      } else {
        throw Exception('Failed to analyze image');
      }
    } catch (e) {
      debugPrint("Error Clarifai: $e");
      return [];
    }
  }
}