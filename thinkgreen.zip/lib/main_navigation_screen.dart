//זהו המסך הראשי של האפליקציה, שמכיל את הניווט התחתון ואת כל המסכים המרכזיים של האפליקציה. הוא משתמש ב-GlobalKey כדי לאפשר גישה לסטייט שלו מכל מקום באפליקציה, מה שמאפשר לנו לעדכן את המסך הנוכחי גם ממסכים אחרים.


import 'package:flutter/material.dart';
import 'screens/home/home_screen.dart';
import 'screens/activities/activities_menu_screen.dart';
import 'screens/rewards/redeem_screen.dart';
import 'screens/challenges/challenges_screen.dart';
import 'screens/profile/profile_screen.dart';

// המפתח חייב להיות פומבי וגלובלי
final GlobalKey<MainNavigationScreenState> navKey = GlobalKey<MainNavigationScreenState>();

class MainNavigationScreen extends StatefulWidget {
  // הסרנו את ה-const! זה מה שפתר את השגיאה
  MainNavigationScreen() : super(key: navKey);

  @override
  MainNavigationScreenState createState() => MainNavigationScreenState();
}

class MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  void updateIndex(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List<Widget> _screens = [
    const HomeScreen(),          
    const ActivitiesMenuScreen(),  
    const RedeemScreen(),          
    const ChallengesScreen(),      
    const ProfileScreen(), 
  ];

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(color: Color(0x33000000), blurRadius: 20, offset: Offset(0, 10))
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: _screens[_currentIndex],
                  bottomNavigationBar: BottomNavigationBar(
                    currentIndex: _currentIndex,
                    onTap: (index) => updateIndex(index),
                    type: BottomNavigationBarType.fixed,
                    backgroundColor: Colors.white,
                    selectedItemColor: darkGreen,
                    unselectedItemColor: Colors.grey,
                    selectedFontSize: 10,
                    unselectedFontSize: 10,
                    items: const [
                      BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                      BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Activities'),
                      BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: 'Rewards'),
                      BottomNavigationBarItem(icon: Icon(Icons.layers), label: 'Challenges'),
                      BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}