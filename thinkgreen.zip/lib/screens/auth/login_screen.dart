// זהו מסך הלוגין הראשוני של האפליקציה, שמאפשר למשתמש לבחור בין כניסה לחשבון קיים לבין יצירת חשבון חדש.
//בנוסף, יש אפשרות לכניסה כאדמין, שמוגנת עם סיסמה קבועה, וניווט למסך איפוס סיסמה במקרה של שכחה.


import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'signin_screen.dart';
import 'signup_screen.dart';
import '../../main_navigation_screen.dart';
import '../admin/admin_home_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  void _showAdminAuthDialog(BuildContext context) {
    final TextEditingController passController = TextEditingController();
    const Color darkGreen = Color(0xFF1B5E20);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.admin_panel_settings, color: darkGreen),
            const SizedBox(width: 10),
            Text('Admin Auth', 
              style: GoogleFonts.outfit(fontWeight: FontWeight.bold, color: darkGreen)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter admin password (123456):'),
            const SizedBox(height: 20),
            TextField(
              controller: passController,
              obscureText: true,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'Password',
                prefixIcon: const Icon(Icons.vpn_key_outlined, color: darkGreen),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL', style: TextStyle(color: Colors.grey))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: darkGreen),
            onPressed: () {
              if (passController.text == '123456') {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (context) => const AdminHomeScreen()));
              }
            },
            child: const Text('LOGIN', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x33000000), // צל Hex יציב (20%)
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 20, right: 20,
                    child: Icon(Icons.notifications_none, color: Colors.grey[700]),
                  ),
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Think Green',
                            style: GoogleFonts.outfit(fontSize: 40, fontWeight: FontWeight.bold, color: darkGreen)),
                          Text('Be the future of our WORLD!',
                            style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                          const SizedBox(height: 40),
                          
                          _buildButton(
                            text: 'Sign In',
                            bgColor: const Color(0xFF00695C),
                            textColor: Colors.white,
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SignInScreen())),
                          ),
                          const SizedBox(height: 15),
                          _buildButton(
                            text: 'Sign Up',
                            bgColor: const Color(0xFFC8E6C9),
                            textColor: darkGreen,
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SignUpScreen())),
                          ),
                          
                          // תיקון הניווט ל-Forgot Password
                          TextButton(
                            onPressed: () => Navigator.pushNamed(context, '/forgot_password'),
                            child: Text('Forgot Password?', style: TextStyle(color: Colors.grey[700], fontSize: 12)),
                          ),
                          
                          const SizedBox(height: 20),
                          const Divider(),
                          const SizedBox(height: 20),

                          _buildButton(
                            text: 'Admin Log In',
                            bgColor: darkGreen,
                            textColor: Colors.white,
                            width: 180,
                            onPressed: () => _showAdminAuthDialog(context),
                          ),
                          
                          const SizedBox(height: 15),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MainNavigationScreen())),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                              ),
                              child: const Text("TEST: LOG IN AS USER", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton({required String text, required Color bgColor, required Color textColor, required VoidCallback onPressed, double? width}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      width: width ?? double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: bgColor,
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        child: Text(text, style: TextStyle(color: textColor, fontSize: 16, fontWeight: FontWeight.w600)),
      ),
    );
  }
}