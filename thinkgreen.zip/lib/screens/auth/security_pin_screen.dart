// זהו מסך ה-Security PIN של האפליקציה, שמאפשר למשתמש להגדיר או לאמת קוד PIN לשם אבטחת החשבון שלו. המסך יכול לשמש גם להגדרת PIN חדש או לאימות PIN קיים בעת ביצוע פעולות רגישות בפרופיל המשתמש.

import 'package:flutter/material.dart';

class SecurityPinScreen extends StatelessWidget {
  final bool isFromProfile;
  const SecurityPinScreen({super.key, this.isFromProfile = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context))),
      body: const Center(child: Text("Security PIN - Coming Soon")),
    );
  }
}