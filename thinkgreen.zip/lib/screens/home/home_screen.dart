// מסך הבית של האפליקציה
// כאן יוצגו נקודות המשתמש, פעילויות אחרונות, ואת האפשרות לדווח על פעילות ירוקה חדשה או לממש נקודות


import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/activity_provider.dart';
import '../activities/manual_report_screen.dart'; 
import '../../main_navigation_screen.dart'; // הייבוא הזה פותר את השגיאה של navKey

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);
    const Color lightGreenText = Color(0xFF66BB6A); 
    
    final totalPoints = context.watch<ActivityProvider>().totalPoints;

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded( 
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Hi, Welcome Back – Jon Doe',
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(color: darkGreen, fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const Text('Good Morning', style: TextStyle(color: lightGreenText)),
                  ],
                ),
              ),
              IconButton(icon: const Icon(Icons.notifications_none, color: darkGreen), onPressed: () {}),
            ],
          ),
          const SizedBox(height: 30),
          Center(
            child: Column(
              children: [
                Text('Your Points', style: GoogleFonts.outfit(color: darkGreen, fontSize: 18)),
                Text(totalPoints.toString(), style: GoogleFonts.outfit(color: darkGreen, fontSize: 48, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity, height: 14,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: (totalPoints / 5000).clamp(0.0, 1.0),
                    child: Container(decoration: BoxDecoration(color: darkGreen, borderRadius: BorderRadius.circular(10))),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 40),
          Text('Quick Actions', style: GoogleFonts.outfit(color: darkGreen, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 15),
          Row(
            children: [
              _buildQuickAction(context, 'Report Green\nActivity', Icons.add_circle_outline, darkGreen, 
                  () => Navigator.push(context, MaterialPageRoute(builder: (context) => const ManualReportScreen()))),
              const SizedBox(width: 12),
              _buildQuickAction(context, 'Redeem\nPoints', Icons.card_giftcard, darkGreen, 
                  () => navKey.currentState?.updateIndex(2)),
              const SizedBox(width: 12),
              _buildQuickAction(context, 'Explore\nChallenges', Icons.explore_outlined, darkGreen, 
                  () => navKey.currentState?.updateIndex(3)),
            ],
          ),
          const SizedBox(height: 35),
          _buildSectionHeader(darkGreen, 'Recent Activity'),
          const SizedBox(height: 12),
          _buildActivityItem(darkGreen, 'Recycled Plastic Bottles', '+20pts'),
          _buildActivityItem(darkGreen, 'Use 5/7 Bus Drives This Week', '+20pts'),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildQuickAction(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
          child: Column(
            children: [
              Icon(icon, color: Colors.white, size: 28),
              const SizedBox(height: 10),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, height: 1.2)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(Color color, String title) {
    return Text(title, style: GoogleFonts.outfit(color: color, fontSize: 19, fontWeight: FontWeight.bold));
  }

  Widget _buildActivityItem(Color color, String title, String pts) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 14))),
          Text(pts, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}