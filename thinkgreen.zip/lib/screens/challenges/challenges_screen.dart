// מסך האתגרים - מציג את האתגרים השבועיים למשתמש
// כאן נציג את האתגרים הזמינים, עם פרטים על כל אתגר ופס התקדמות


import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/challenge_provider.dart';
import '../../models/challenge.dart';

class ChallengesScreen extends StatelessWidget {
  const ChallengesScreen({super.key});

  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Header
        _buildHeader(),

        Expanded(
          child: Consumer<ChallengeProvider>(
            builder: (context, challengeProvider, child) {
              if (challengeProvider.challenges.isEmpty) {
                return const Center(child: Text("No challenges available yet."));
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: challengeProvider.challenges.length,
                itemBuilder: (context, index) {
                  final challenge = challengeProvider.challenges[index];
                  return _buildChallengeCard(challenge);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          Text(
            'Weekly Challenges',
            style: GoogleFonts.outfit(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: darkGreen,
            ),
          ),
          Text(
            'Complete tasks to earn big points!',
            style: TextStyle(color: darkGreen.withValues(alpha: 0.6)),
          ),
        ],
      ),
    );
  }

  Widget _buildChallengeCard(Challenge challenge) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10)],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text(challenge.icon, style: const TextStyle(fontSize: 35)),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(challenge.title, style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 18, color: darkGreen)),
                    Text('${challenge.daysLeft} days left', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 12)),
                  ],
                ),
              ),
              Text('+${challenge.points}', style: const TextStyle(fontWeight: FontWeight.w900, color: darkGreen, fontSize: 20)),
            ],
          ),
          const SizedBox(height: 20),
          
          // פס התקדמות
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: challenge.progress,
                    backgroundColor: lightGreenBg,
                    color: darkGreen,
                    minHeight: 10,
                  ),
                ),
              ),
              const SizedBox(width: 15),
              Text('${challenge.currentCount}/${challenge.targetCount}', 
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ],
          ),
          
          const SizedBox(height: 15),
          
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                // לוגיקה זמנית לקידום האתגר לצורך הבדיקה
                // בעתיד זה יתעדכן אוטומטית מהדיווחים
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: darkGreen),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Complete Action', style: TextStyle(color: darkGreen, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}