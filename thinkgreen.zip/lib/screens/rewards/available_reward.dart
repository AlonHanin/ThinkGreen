import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AvailableRewardsScreen extends StatelessWidget {
  const AvailableRewardsScreen({super.key});

  // צבעי המותג המאוחדים שלנו
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  // נתונים לדוגמה
  final List<Map<String, String>> rewards = const [
    {'title': 'Free Coffee (Reusable Cup)', 'cost': '250', 'icon': '☕'},
    {'title': '10% Store Discount', 'cost': '300', 'icon': '🛍️'},
    {'title': 'Bus Ticket Credit', 'cost': '200', 'icon': '🚌'},
    {'title': 'Tree Planting Donation', 'cost': '300', 'icon': '🌳'},
    {'title': 'Free Drink Upgrade', 'cost': '200', 'icon': '🥤'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0), // רקע ה"דסקטופ" האפור
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: lightGreenBg,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text(
                      'Available Rewards',
                      style: GoogleFonts.outfit(
                        color: darkGreen,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    centerTitle: true,
                  ),
                  body: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          "Choose A Reward And Redeem Your Points:",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            color: darkGreen.withValues(alpha: 0.7),
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          physics: const BouncingScrollPhysics(),
                          itemCount: rewards.length,
                          itemBuilder: (context, index) {
                            return _buildRewardCard(
                              rewards[index]['title']!,
                              rewards[index]['cost']!,
                              rewards[index]['icon']!,
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRewardCard(String title, String cost, String emoji) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: darkGreen.withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // אייקון/אימוג'י של הפרס
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: lightGreenBg,
              borderRadius: BorderRadius.circular(15),
            ),
            alignment: Alignment.center,
            child: Text(emoji, style: const TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 15),
          // פרטי הפרס
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.outfit(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: darkGreen,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "$cost Points",
                  style: TextStyle(
                    color: darkGreen.withValues(alpha: 0.6),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // כפתור מימוש
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: darkGreen,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              minimumSize: const Size(60, 30),
            ),
            child: const Text(
              "Redeem",
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}