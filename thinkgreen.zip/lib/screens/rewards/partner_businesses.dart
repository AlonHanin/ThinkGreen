import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PartnerBusinessesScreen extends StatelessWidget {
  const PartnerBusinessesScreen({super.key});

  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  final List<Map<String, String>> businesses = const [
    {'name': 'Eco Coffee Hub', 'rewards': 'Discounts, Reusable Items', 'location': 'Main St. 12'},
    {'name': 'Green Fashion', 'rewards': 'Store Credit, Tote Bags', 'location': 'Shopping Mall, Floor 1'},
    {'name': 'Nature Market', 'rewards': 'Fresh Produce, Discounts', 'location': 'North Ave. 45'},
    {'name': 'Bio Bakery', 'rewards': 'Free Pastry, Coffee', 'location': 'Central Square'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: lightGreenBg,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text('Partners', style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold, fontSize: 18)),
                    centerTitle: true,
                  ),
                  body: Column(
                    children: [
                      const Text("Where to use your rewards:", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 15),
                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          itemCount: businesses.length,
                          itemBuilder: (context, index) => _buildBusinessCard(businesses[index]),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBusinessCard(Map<String, String> biz) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: darkGreen.withValues(alpha: 0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(biz['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: darkGreen)),
          const SizedBox(height: 5),
          Text("Rewards: ${biz['rewards']}", style: const TextStyle(fontSize: 12, color: Colors.black87)),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.location_on_outlined, size: 14, color: Colors.grey),
              const SizedBox(width: 4),
              Text(biz['location']!, style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}