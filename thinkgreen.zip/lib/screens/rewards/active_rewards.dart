import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'qr_code.dart';

class ActiveRewardsScreen extends StatelessWidget {
  const ActiveRewardsScreen({super.key});

  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  final List<Map<String, String>> activeRewards = const [
    {'title': '10% Discount At Partner Store', 'cost': '300 Points'},
    {'title': 'Free Beverage Upgrade', 'cost': '200 Points'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: lightGreenBg,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text('My Active Rewards', style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold, fontSize: 18)),
                    centerTitle: true,
                  ),
                  body: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: Text("Redeemed rewards ready to use:", textAlign: TextAlign.center, style: TextStyle(fontSize: 13)),
                      ),
                      const SizedBox(height: 20),
                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          itemCount: activeRewards.length,
                          itemBuilder: (context, index) => _buildActiveCard(context, activeRewards[index]),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActiveCard(BuildContext context, Map<String, String> reward) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 4))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(reward['title']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: darkGreen)),
                const SizedBox(height: 4),
                Text(reward['cost']!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const QRCodeScreen())),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: darkGreen, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.qr_code_2, color: Colors.white, size: 28),
            ),
          ),
        ],
      ),
    );
  }
}