import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'available_reward.dart'; 
import 'partner_businesses.dart'; 
import 'active_rewards.dart';

class RedeemScreen extends StatefulWidget {
  const RedeemScreen({super.key});

  @override
  State<RedeemScreen> createState() => _RedeemScreenState();
}

class _RedeemScreenState extends State<RedeemScreen> {
  // צבעי המותג המעודכנים
  static const Color darkGreen = Color(0xFF1B5E20);
  

  @override
  Widget build(BuildContext context) {
    return Column( // "שטוח" כדי להיכנס ל-MainNavigationScreen
      children: [
        // Header
        _buildHeader(),

        Expanded(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 10),
                Text(
                  "Use Your Points To Get Rewards And\nBenefits",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.outfit(
                    color: darkGreen.withValues(alpha: 0.7),
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),

                const SizedBox(height: 25),

                // Points Card
                _buildPointsCard(),

                const SizedBox(height: 30),

                // Progress Section
                _buildProgressSection(),

                const SizedBox(height: 30),

                // Navigation Cards
                _buildNavigationCard(
                  "What Can You Do With Your Points?",
                  "View Available Rewards",
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AvailableRewardsScreen()),
                  ),
                ),
                _buildNavigationCard(
                  "See Where Rewards Can Be Used",
                  "Partner Businesses",
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PartnerBusinessesScreen()),
                  ),
                ),
                _buildNavigationCard(
                  "Rewards You Redeemed But Haven't Used Yet",
                  "My Active Rewards",
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const ActiveRewardsScreen()),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(width: 40), // איזון ויזואלי
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: GoogleFonts.outfit(color: darkGreen, fontSize: 28, height: 1.1),
              children: const [
                TextSpan(text: 'Redeem\n', style: TextStyle(fontWeight: FontWeight.w300)),
                TextSpan(text: 'Points', style: TextStyle(fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none, color: darkGreen),
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildPointsCard() {
    return Container(
      padding: const EdgeInsets.all(25),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            "Your Points:",
            style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold, color: darkGreen),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
            decoration: BoxDecoration(
              color: darkGreen.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              "1240",
              style: GoogleFonts.outfit(fontSize: 32, fontWeight: FontWeight.w900, color: darkGreen),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressSection() {
    return Column(
      children: [
        Text(
          "You're Getting Closer To Your Next Reward!",
          textAlign: TextAlign.center,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: darkGreen.withValues(alpha: 0.8)),
        ),
        const SizedBox(height: 15),
        Container(
          height: 12,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: 0.7,
            child: Container(
              decoration: BoxDecoration(
                color: darkGreen,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          "Next Reward At: 300 Points",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12, color: darkGreen),
        ),
      ],
    );
  }

  Widget _buildNavigationCard(String title, String buttonText, {required VoidCallback onTap}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5, bottom: 5),
          child: Text(
            title,
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12, color: darkGreen.withValues(alpha: 0.6)),
          ),
        ),
        GestureDetector(
          onTap: onTap,
          child: Container(
            margin: const EdgeInsets.only(bottom: 15),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: darkGreen.withValues(alpha: 0.05)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  buttonText,
                  style: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 16, color: darkGreen),
                ),
                const Icon(Icons.arrow_forward_ios, size: 18, color: darkGreen),
              ],
            ),
          ),
        ),
      ],
    );
  }
}