// זהו מסך הבית של האדמין, שמאפשר לו ליצור אתגרים חדשים, לצפות בסטטיסטיקות כלליות של המערכת ולסקור בקשות לאישור אתגרים שהמשתמשים הגישו.
// המסך בנוי בצורה של כרטיסים גדולים וברורים, עם ניווט פשוט וידידותי למשתמש, ומאפשר לאדמין לנהל את האפליקציה בצורה יעילה ונוחה.

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/challenge_provider.dart';
import '../../models/challenge.dart';
import 'admin_approvals_screen.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  // רשימת תבניות האתגרים המובנית
  final List<Map<String, dynamic>> _challengeTemplates = [
    {'title': 'מיחזור בקבוקים', 'points': 150, 'target': 10, 'icon': '♻️', 'desc': 'מיחזור בקבוקי פלסטיק/זכוכית'},
    {'title': 'נסיעה באוטובוס', 'points': 200, 'target': 5, 'icon': '🚌', 'desc': 'שימוש בתחבורה ציבורית במקום רכב פרטי'},
    {'title': 'דיווש ליעד', 'points': 350, 'target': 3, 'icon': '🚲', 'desc': 'רכיבה על אופניים למרחק משמעותי'},
    {'title': 'ניקוי פארק קהילתי', 'points': 500, 'target': 1, 'icon': '🌳', 'desc': 'השתתפות ביום ניקיון במרחב הציבורי'},
    {'title': 'קנייה ללא שקיות', 'points': 80, 'target': 5, 'icon': '🛍️', 'desc': 'שימוש בסלים רב-פעמיים בלבד'},
    {'title': 'תרומת בגדים', 'points': 300, 'target': 1, 'icon': '📦', 'desc': 'מסירת בגדים לשימוש חוזר בעמדת איסוף'},
    {'title': 'דיווח על מפגע סביבתי', 'points': 150, 'target': 1, 'icon': '⚠️', 'desc': 'דיווח למוקד עירוני על זיהום/מפגע'},
    {'title': 'מעבר לחשבוניות דיגיטליות', 'points': 100, 'target': 10, 'icon': '📱', 'desc': 'ביטול דואר נייר ומעבר למייל'},
    {'title': 'קנייה בתפזורת', 'points': 120, 'target': 3, 'icon': '🌾', 'desc': 'רכישת מזון ללא אריזות פלסטיק'},
    {'title': 'החתמת חבר לקהילה', 'points': 400, 'target': 1, 'icon': '🤝', 'desc': 'צירוף משתמש חדש לאפליקציה'},
  ];

  Map<String, dynamic>? _selectedTemplate;
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 7));
  
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _pointsController = TextEditingController();
  final TextEditingController _targetController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _pointsController.dispose();
    _targetController.dispose();
    super.dispose();
  }

  void _updateFieldsFromTemplate(Map<String, dynamic> template) {
    setState(() {
      _selectedTemplate = template;
      _nameController.text = template['title'];
      _pointsController.text = template['points'].toString();
      _targetController.text = template['target'].toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: lightGreenBg,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.exit_to_app, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text('Admin Control', style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold)),
                    centerTitle: true,
                  ),
                  body: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        _buildAdminCard(context, 'Create New\nChallenge', Icons.add_task, () => _showCreateChallengeDialog(context)),
                        const SizedBox(height: 15),
                        _buildAdminCard(context, 'System\nStatistics', Icons.bar_chart, () {}),
                        const SizedBox(height: 15),
                        _buildAdminCard(
                          context, 
                          'Review\nRequests', 
                          Icons.fact_check, 
                          () => Navigator.push(context, MaterialPageRoute(builder: (context) => const AdminApprovalsScreen())),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAdminCard(BuildContext context, String title, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white, 
          borderRadius: BorderRadius.circular(20), 
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.5), blurRadius: 10)]
        ),
        child: Row(
          children: [
            Icon(icon, size: 40, color: darkGreen),
            const SizedBox(width: 20),
            Text(title, style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: darkGreen)),
          ],
        ),
      ),
    );
  }

  void _showCreateChallengeDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Container(
          height: MediaQuery.of(context).size.height * 0.8,
          decoration: const BoxDecoration(
            color: Colors.white, 
            borderRadius: BorderRadius.vertical(top: Radius.circular(30))
          ),
          padding: const EdgeInsets.all(25),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ה-Header עם ה-X שביקשת
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Publish New Challenge', style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold, color: darkGreen)),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.grey),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                
                DropdownButtonFormField<Map<String, dynamic>>(
                  decoration: InputDecoration(
                    labelText: 'Choose from Templates',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  items: _challengeTemplates.map((t) => DropdownMenuItem(value: t, child: Text("${t['icon']} ${t['title']}"))).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      _updateFieldsFromTemplate(val);
                      setModalState(() {}); 
                    }
                  },
                ),
                
                const SizedBox(height: 20),
                _buildTextField('Challenge Name', Icons.edit, _nameController),
                const SizedBox(height: 15),
                Row(
                  children: [
                    Expanded(child: _buildTextField('Points', Icons.stars, _pointsController, isNumber: true)),
                    const SizedBox(width: 10),
                    Expanded(child: _buildTextField('Target', Icons.repeat, _targetController, isNumber: true)),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                InkWell(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (picked != null) setModalState(() => _selectedDate = picked);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(15)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Ends on: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}", style: const TextStyle(fontSize: 16)),
                        const Icon(Icons.calendar_month, color: darkGreen),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 30),
                
                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: darkGreen, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                    onPressed: () {
                      if (_nameController.text.isNotEmpty) {
                        final newChallenge = Challenge(
                          id: DateTime.now().toString(),
                          title: _nameController.text,
                          description: _selectedTemplate?['desc'] ?? "No description",
                          points: int.tryParse(_pointsController.text) ?? 0,
                          targetCount: int.tryParse(_targetController.text) ?? 1,
                          endDate: _selectedDate,
                          icon: _selectedTemplate?['icon'] ?? '🌱',
                        );
                        Provider.of<ChallengeProvider>(context, listen: false).addChallenge(newChallenge);
                        Navigator.pop(context);
                      }
                    },
                    child: const Text('PUBLISH NOW', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, IconData icon, TextEditingController controller, {bool isNumber = false}) {
    return TextField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: darkGreen),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}