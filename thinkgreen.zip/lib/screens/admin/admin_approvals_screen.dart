// זהו מסך האדמין שמאפשר לו לעיין בבקשות הפעילויות שהמשתמשים הגישו לאישור או דחייה.
// האדמין יכול לראות את פרטי הפעילות, כולל תמונה אם קיימת, ולבחור לאשר או לדחות את הבקשה. אם אין בקשות ממתינות, יוצג מסך ריק עם הודעה מתאימה.

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import '../../providers/activity_provider.dart';
import '../../models/green_activity.dart';

class AdminApprovalsScreen extends StatelessWidget {
  const AdminApprovalsScreen({super.key});

  static const Color darkGreen = Color(0xFF1B5E20);
  static const Color lightGreenBg = Color(0xFFE8F5E9);

  @override
  Widget build(BuildContext context) {
    final pendingActivities = Provider.of<ActivityProvider>(context)
        .activities
        .where((a) => a.status == ActivityStatus.pending)
        .toList();

    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0), // רקע דסקטופ
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: lightGreenBg,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text('Review Requests', 
                      style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold)),
                    centerTitle: true,
                  ),
                  body: pendingActivities.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.all(15),
                          itemCount: pendingActivities.length,
                          itemBuilder: (context, index) => _buildReviewCard(context, pendingActivities[index]),
                        ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.done_all_rounded, size: 80, color: darkGreen.withValues(alpha: 0.5)),
          const SizedBox(height: 15),
          Text('All caught up!', style: GoogleFonts.outfit(fontSize: 20, color: darkGreen, fontWeight: FontWeight.w500)),
          Text('No pending requests to review.', style: TextStyle(color: darkGreen.withValues(alpha: 0.5))),
        ],
      ),
    );
  }

  Widget _buildReviewCard(BuildContext context, GreenActivity activity) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.5), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: const CircleAvatar(backgroundColor: lightGreenBg, child: Icon(Icons.person, color: darkGreen)),
            title: Text(activity.userName ?? "Unknown User", style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(activity.title),
            trailing: Text('+${activity.points}', style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
          ),
          if (activity.imageUrl != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.file(
                  File(activity.imageUrl!),
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Provider.of<ActivityProvider>(context, listen: false).rejectActivity(activity.id),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.red),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Reject', style: TextStyle(color: Colors.red)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Provider.of<ActivityProvider>(context, listen: false).approveActivity(activity.id),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: darkGreen,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Approve', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}