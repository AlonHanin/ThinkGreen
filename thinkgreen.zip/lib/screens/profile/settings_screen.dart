//זה מסך ההגדרות של הפרופיל, שם המשתמש יכול לשנות את ההגדרות שלו כמו התראות, מצב כהה, שירותי מיקום ועוד.
//המסך בנוי עם AppBar פשוט ו-ListView שמכיל כמה אפשרויות עם SwitchListTile ו-ListTile רגילים. כל אפשרות מעוצבת עם צבעים ירוקים בהירים ועם פונטים מודרניים כדי לשמור על המראה הכללי של האפליקציה.


import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool ntf = true;
  bool dark = false;
  bool location = true;

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: darkGreen, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Settings',
          style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildSectionTitle('Notifications'),
          _buildSwitchTile('Push Notifications', 'Get updates on challenges', ntf, (v) => setState(() => ntf = v)),
          
          const SizedBox(height: 20),
          _buildSectionTitle('Appearance'),
          _buildSwitchTile('Dark Mode', 'Change app theme', dark, (v) => setState(() => dark = v)),
          
          const SizedBox(height: 20),
          _buildSectionTitle('Privacy'),
          _buildSwitchTile('Location Services', 'Track green travels', location, (v) => setState(() => location = v)),
          
          const SizedBox(height: 30),
          _buildSimpleTile('Language', 'English (US)', Icons.language),
          _buildSimpleTile('Terms of Service', '', Icons.description_outlined),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, bottom: 10),
      child: Text(
        title,
        style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.bold, color: const Color(0xFF1B5E20)),
      ),
    );
  }

  Widget _buildSwitchTile(String title, String sub, bool val, Function(bool) onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F8E9),
        borderRadius: BorderRadius.circular(15),
      ),
      child: SwitchListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        value: val,
        activeThumbColor: const Color(0xFF1B5E20),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildSimpleTile(String title, String trailing, IconData icon) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFF1B5E20)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailing.isNotEmpty) Text(trailing, style: const TextStyle(color: Colors.grey)),
          const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
        ],
      ),
      onTap: () {},
    );
  }
}