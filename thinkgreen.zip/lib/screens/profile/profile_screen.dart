// מסך הפרופיל - ProfileScreen
// כאן המשתמש יכול לראות את הפרטים שלו, לערוך אותם, לשנות הגדר


import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'edit_profile_screen.dart';
import '../auth/security_pin_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Column(
      children: [
        // Header: הירוק עם תמונת הפרופיל
        Container(
          height: 200,
          width: double.infinity,
          decoration: const BoxDecoration(color: darkGreen),
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Positioned(
                top: 20,
                child: Text(
                  'Profile',
                  style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Positioned(
                bottom: -50,
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 55,
                      backgroundColor: Colors.white,
                      child: CircleAvatar(
                        radius: 52,
                        backgroundImage: NetworkImage('https://i.pravatar.cc/300'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'John Smith',
                      style: GoogleFonts.outfit(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: darkGreen,
                      ),
                    ),
                    const Text(
                      'ID: 25030024',
                      style: TextStyle(color: Color(0xFF9E9E9E), fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 70),

        // רשימת האפשרויות
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 25),
            children: [
              _buildItem(
                context,
                Icons.person_outline,
                'Edit Profile',
                const EditProfileScreen(),
                const Color(0xFFE3F2FD),
                Colors.blue,
              ),
              _buildItem(
                context,
                Icons.security_outlined,
                'Security',
                const SecurityPinScreen(isFromProfile: true),
                const Color(0xFFF3E5F5),
                Colors.purple,
              ),
              _buildItem(
                context,
                Icons.settings_outlined,
                'Setting',
                const SettingsScreen(),
                const Color(0xFFE8F5E9),
                Colors.green,
              ),
              _buildItem(
                context,
                Icons.help_outline,
                'Help',
                null,
                const Color(0xFFFFF3E0),
                Colors.orange,
              ),
              _buildItem(
                context,
                Icons.logout,
                'Logout',
                null,
                const Color(0xFFFFEBEE),
                Colors.red,
                isLogout: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  // פונקציה לבניית פריט ברשימה עם ניווט עטוף במסגרת טלפון
  Widget _buildItem(BuildContext context, IconData icon, String title, Widget? target, Color bgColor, Color iconColor, {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: bgColor, shape: BoxShape.circle),
          child: Icon(icon, color: iconColor, size: 20),
        ),
        title: Text(
          title,
          style: GoogleFonts.outfit(fontWeight: FontWeight.w500),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
        onTap: () {
          if (isLogout) {
            Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
          } else if (target != null) {
            // ניווט שעוטף את דף היעד בתוך מסגרת הטלפון המעוצבת
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PhoneFrameWrapper(child: target),
              ),
            );
          }
        },
      ),
    );
  }
}

// רכיב המסגרת - PhoneFrameWrapper
// הרכיב הזה מוודא שכל דף שנפתח מהפרופיל נראה בדיוק כמו שאר האפליקציה (בתוך המסגרת המעוגלת)
class PhoneFrameWrapper extends StatelessWidget {
  final Widget child;
  const PhoneFrameWrapper({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0), // הרקע האפור החיצוני
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x33000000), // צל שחור עדין (20%) ללא opacity
                    blurRadius: 20,
                    offset: Offset(0, 10),
                  )
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}