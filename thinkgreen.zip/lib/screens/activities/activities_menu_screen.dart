// זהו מסך התפריט הראשי של הפעילויות, שמאפשר למשתמש לבחור בין דיווח ידני לבין צפייה בהיסטוריית הפעילויות שלו.

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'manual_report_screen.dart';
import 'activity_history_screen.dart'; // זה הדף של הרשימה
import '../../widgets/action_button_widget.dart';


class ActivitiesMenuScreen extends StatelessWidget {
  const ActivitiesMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color darkGreen = Color(0xFF1B5E20);

    return Column(
      children: [
        // Header פשוט
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_none, color: darkGreen),
                onPressed: () {},
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),
        
        RichText(
          textAlign: TextAlign.center,
          text: TextSpan(
            style: GoogleFonts.outfit(color: darkGreen, fontSize: 32, height: 1.1),
            children: const [
              TextSpan(text: 'Green\n', style: TextStyle(fontWeight: FontWeight.w300)),
              TextSpan(text: 'Activities', style: TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
        ),

        const SizedBox(height: 16),
        
        Text(
          'Manage & Track\nYour Green Actions',
          textAlign: TextAlign.center,
          style: GoogleFonts.outfit(
            color: darkGreen.withValues(alpha: 0.7),
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),

        const SizedBox(height: 50),

        // 2 הכפתורים הגדולים
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              ActionButtonWidget(
                title: 'Report Green Activities',
                subtitle: 'Add Your Actions Manually',
                onTap: () => Navigator.push(
                  context, 
                  MaterialPageRoute(builder: (context) => const ManualReportScreen())
                ),
              ),
              const SizedBox(height: 20),
              ActionButtonWidget(
                title: 'Green Activity History',
                subtitle: 'See All Tracked Activities',
                onTap: () => Navigator.push(
                  context, 
                  MaterialPageRoute(builder: (context) => const ActivityHistoryScreen())
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}