// זהו מסך דיווח ידני של האפליקציה, שמאפשר למשתמש לדווח על פעילות ירוקה שביצע באופן ידני, כמו מחזור בקבוקים או שימוש בתחבורה ציבורית.
//המסך כולל תפריט נפתח לבחירת סוג הפעילות, בחירת תאריך ושעה, וכפתור לשליחת הדיווח. לאחר השליחה, הפעילות מתווספת לרשימת הפעילויות של המשתמש, והמשתמש מקבל הודעת הצלחה.
//המסך מעוצב בצורה אסתטית עם צבעי ירוק
//בהירים וכחולים כהים, ומאפשר ניווט חזרה למסך הקודם באמצעות כפתור חזרה באפליקציה.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';

import '../../providers/activity_provider.dart';
import '../../models/green_activity.dart';
import '../../services/clarifai_service.dart'; // וודא שהקובץ קיים בתיקיית services

class ManualReportScreen extends StatefulWidget {
  const ManualReportScreen({super.key});

  @override
  State<ManualReportScreen> createState() => _ManualReportScreenState();
}

class _ManualReportScreenState extends State<ManualReportScreen> {
  // משתני המצב של הטופס
  String? _selectedActivity;
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  
  // משתני מצלמה ו-AI
  File? _image;
  bool _isAnalyzing = false;
  final ClarifaiService _clarifai = ClarifaiService();
  
  final List<String> _activitiesOptions = [
    'Recycled Plastic Bottles',
    'Used Public Transport',
    'Used A Reusable Bottle',
    'Walked / Biked to Work',
  ];

  // עיצוב צבעים (Hex ישיר למניעת שגיאות)
  final Color darkGreen = const Color(0xFF1B5E20);
  final Color lightGreenBg = const Color(0xFFE8F5E9);
  final Color subtleGreenBorder = const Color(0x331B5E20); // שקיפות מובנית ב-Hex

  // פונקציה לצילום תמונה
  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera, imageQuality: 50);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(primary: darkGreen, onPrimary: Colors.white),
          ),
          child: child!,
        );
      },
    );
    if (date != null) setState(() => _selectedDate = date);
  }

  Future<void> _pickTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (time != null) setState(() => _selectedTime = time);
  }

  // שליחת הדיווח עם אינטגרציה של AI
  Future<void> _submit() async {
    if (_selectedActivity == null || _image == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select activity and take a photo')),
      );
      return;
    }

    setState(() => _isAnalyzing = true);

    try {
      final tags = await _clarifai.analyzeImage(_image!);
      
      // בדיקת AI
      bool isVerified = tags.contains('recycling') || 
                        tags.contains('bottle') || 
                        tags.contains('nature') ||
                        tags.contains('transport');

      // פתרון השגיאה של "Async Gaps": בודקים אם המסך עדיין קיים לפני שממשיכים
      if (!mounted) return;

      final dateTime = DateTime(
        _selectedDate.year, _selectedDate.month, _selectedDate.day,
        _selectedTime.hour, _selectedTime.minute,
      );

      final newActivity = GreenActivity(
        id: DateTime.now().toString(),
        title: _selectedActivity!,
        source: ActivitySource.manual,
        dateTime: dateTime,
        points: 20, // או לוגיקת הניקוד שלך
        status: isVerified ? ActivityStatus.approved : ActivityStatus.pending, // תיקון ה-Enum
        imagePath: _image!.path, // עכשיו השדה הזה קיים
      );

      context.read<ActivityProvider>().addActivity(newActivity);

      setState(() => _isAnalyzing = false);
      
      // שוב בדיקת mounted לפני הצגת דיאלוג
      if (!mounted) return;
      _showSuccessDialog(isVerified);

    } catch (e) {
      if (!mounted) return;
      setState(() => _isAnalyzing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Analysis failed: $e')),
      );
    }
  }

  void _showSuccessDialog(bool verified) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Icon(verified ? Icons.check_circle : Icons.hourglass_empty, 
                   color: darkGreen, size: 50),
        content: Text(
          verified 
          ? "AI Verified! Your points have been added." 
          : "Report sent! Admin will verify your photo soon.",
          textAlign: TextAlign.center,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // סגירת הדיאלוג
              Navigator.pop(context); // חזרה למסך הקודם
            },
            child: Text("Awesome!", style: TextStyle(color: darkGreen, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0),
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19,
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: lightGreenBg,
                borderRadius: BorderRadius.circular(30),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    // Header וניווט חזרה
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back_ios, color: darkGreen, size: 20),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Text('Manual Report', 
                          style: GoogleFonts.outfit(color: darkGreen, fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(width: 40), 
                      ],
                    ),

                    const SizedBox(height: 20),

                    // אזור מצלמה
                    GestureDetector(
                      onTap: _takePhoto,
                      child: Container(
                        height: 150,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: subtleGreenBorder),
                        ),
                        child: _image == null
                            ? Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.add_a_photo, color: darkGreen, size: 40),
                                  const SizedBox(height: 8),
                                  Text('Tap to take a photo', style: TextStyle(color: darkGreen, fontSize: 12)),
                                ],
                              )
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: Image.file(_image!, fit: BoxFit.cover),
                              ),
                      ),
                    ),

                    const SizedBox(height: 25),

                    // Dropdown לבחירת פעילות
                    _buildSectionLabel("What did you do?"),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          hint: Text('Choose Activity', style: TextStyle(color: darkGreen, fontSize: 14)),
                          value: _selectedActivity,
                          isExpanded: true,
                          items: _activitiesOptions.map((String value) {
                            return DropdownMenuItem(value: value, child: Text(value, style: const TextStyle(fontSize: 14)));
                          }).toList(),
                          onChanged: (val) => setState(() => _selectedActivity = val),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // בחירת תאריך וזמן
                    Row(
                      children: [
                        _buildPickerTile(
                          icon: Icons.calendar_today,
                          label: DateFormat('dd/MM/yyyy').format(_selectedDate),
                          onTap: _pickDate,
                        ),
                        const SizedBox(width: 15),
                        _buildPickerTile(
                          icon: Icons.access_time,
                          label: _selectedTime.format(context),
                          onTap: _pickTime,
                        ),
                      ],
                    ),

                    const SizedBox(height: 30),

                    // כפתור SUBMIT עם מצב טעינה (AI Analysis)
                    SizedBox(
                      width: double.infinity,
                      height: 55,
                      child: ElevatedButton(
                        onPressed: _isAnalyzing ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: darkGreen,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                          disabledBackgroundColor: Colors.grey,
                        ),
                        child: _isAnalyzing
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text(
                                'SUBMIT & VERIFY',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(label, style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold, fontSize: 14)),
    );
  }

  Widget _buildPickerTile({required IconData icon, required String label, required VoidCallback onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Column(
            children: [
              Icon(icon, color: darkGreen, size: 20),
              const SizedBox(height: 5),
              Text(label, style: TextStyle(color: darkGreen, fontWeight: FontWeight.w600, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}