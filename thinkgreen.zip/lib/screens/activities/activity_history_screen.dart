// זהו מסך היסטוריית הפעילויות של האפליקציה,
//שמציג למשתמש רשימה של כל הפעילויות שדווחו בעבר, עם אפשרות לסנן בין כל הפעילויות לבין דיווחים ידניים בלבד.
//המסך מעוצב בצורה אסתטית עם צבעי ירוק בהירים וכחולים כהים, ומאפשר ניווט חזרה למסך הקודם באמצעות כפתור חזרה באפליקציה.

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/activity_provider.dart';
import '../../widgets/activity_history_card.dart';

class ActivityHistoryScreen extends StatefulWidget {
  const ActivityHistoryScreen({super.key});

  @override
  State<ActivityHistoryScreen> createState() => _ActivityHistoryScreenState();
}

class _ActivityHistoryScreenState extends State<ActivityHistoryScreen> {
  String _currentFilter = 'All';

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ActivityProvider>(context);
    const Color darkGreen = Color(0xFF1B5E20);
    const Color lightGreenBg = Color(0xFFE8F5E9);

    final filteredActivities = provider.activities.where((activity) {
      if (_currentFilter == 'All') return true;
      return activity.source.toString().contains('manual');
    }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFE0E0E0), // הרקע האפור של ה"דסקטופ"
      body: SafeArea(
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 19, // מבנה פלאפון
            child: Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: lightGreenBg,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Scaffold(
                  backgroundColor: Colors.transparent,
                  appBar: AppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    leading: IconButton(
                      icon: const Icon(Icons.arrow_back, color: darkGreen),
                      onPressed: () => Navigator.pop(context),
                    ),
                    title: Text('History', 
                      style: GoogleFonts.outfit(color: darkGreen, fontWeight: FontWeight.bold, fontSize: 18)),
                    centerTitle: true,
                  ),
                  body: Column(
                    children: [
                      const SizedBox(height: 10),
                      // פילטרים
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: ['All', 'Manual'].map((filter) {
                          final isSelected = _currentFilter == filter;
                          return GestureDetector(
                            onTap: () => setState(() => _currentFilter = filter),
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                              decoration: BoxDecoration(
                                color: isSelected ? darkGreen : Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(color: darkGreen.withValues(alpha: 0.1)),
                              ),
                              child: Text(
                                filter,
                                style: TextStyle(
                                  color: isSelected ? Colors.white : darkGreen,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 15),
                      Expanded(
                        child: filteredActivities.isEmpty 
                          ? Center(child: Text("No activities found", style: TextStyle(color: darkGreen.withValues(alpha: 0.5))))
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 10),
                              itemCount: filteredActivities.length,
                              itemBuilder: (context, index) {
                                return ActivityHistoryCard(activity: filteredActivities[index]);
                              },
                            ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}